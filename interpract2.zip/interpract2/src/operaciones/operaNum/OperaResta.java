package operaciones.operaNum;

public class OperaResta {
     private int a=0, b=0;
    
    public OperaResta(int a, int b){
    this.a = a;
    this.b = b;
    }
    public int rresta(){
        return(a-b);
    
    }
}
