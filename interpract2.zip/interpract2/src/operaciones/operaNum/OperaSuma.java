
package operaciones.operaNum;

public class OperaSuma { 
    private int a=0, b=0;
    
    public OperaSuma(int a, int b){
    this.a = a;
    this.b = b;
    }
    public int rsuma(){
        return(a+b);
        
    }
    
}
