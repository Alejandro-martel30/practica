
package operaciones.operatext;

public class operaConectar {
    String a= "" , b= "";
    
    public operaConectar(String a, String b){
        this.a=a;
        this.b=b;
    }
    
    public String rcadena(){
        return (a+b);
    }
    
}
